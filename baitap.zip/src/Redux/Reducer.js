import { STAFFS } from "../components/Staffs";

export const initialState = {
    staffs: STAFFS,
}

export const Reducer = (state = initialState, action) => {
    return state;
}