import React from 'react';

class ChangeColumn extends React.Component {
    render() {
        return (
            <button onClick={() => { this.props.onClickChange() }}>Đổi Giao Diện 4 Cột</button>
        )
    }
}

export default ChangeColumn;