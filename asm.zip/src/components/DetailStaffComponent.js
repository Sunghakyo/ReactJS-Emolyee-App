import { Breadcrumb, BreadcrumbItem } from 'reactstrap';
import { Link } from 'react-router-dom';
import { LocalForm, Control, Errors } from 'react-redux-form';
import { Col, Label, Row, Modal, ModalBody, ModalHeader, Button } from 'reactstrap';
import React, { useState } from 'react';

const required = (val) => val && val.length;
const maxLength = (len) => val => !val || val.length <= len;
const minLength = (len) => val => !val || val.length >= len;

function RenderStaffs({ staff, departName }) {
  const [isOpen, setOpen] = useState(false);

  return (<>
    <div className="col-12 col-md-2 col-lg-2">
      <img src="/assets/images/alberto.png" alt="avatar" />
    </div>
    <div className=" col-12 col-md-10 col-lg-10 ">
      <h2>Họ và tên: {staff.name}</h2>
      <p> Ngày sinh: {staff.doB} </p>
      <p>Ngày vào công ty:{staff.startDate}</p>
      <p>Phòng ban:{departName.name} </p>
      <p>Số ngày nghỉ còn lại: {staff.annualLeave}</p>
      <p>Số ngày làm thêm: {staff.overTime}</p>
      <button className="btn btn-primary mb-3" onClick={() => { setOpen(!isOpen); }}> chỉnh sửa</button>
    </div>

    <ModalEdit
      isOpen={isOpen}
      setOpen={setOpen}
      name={staff.name}
      doB={staff.doB}
      startDate={staff.startDate}
      depart={departName.name}
      annual={staff.annualLeave}
      overTime={staff.overTime}
    />
  </>
  )
}

function ModalEdit({ isOpen, setOpen, name, doB, startDate, depart, annual, overTime }) {

  const handleSubmit = (value) => {
    console.log(value)
  }

  return (
    <Modal isOpen={isOpen} toggle={() => setOpen(!isOpen)} >
      <ModalHeader>Chỉnh sửa thông tin</ModalHeader>
      <ModalBody >
        <LocalForm onSubmit={values => handleSubmit(values)}>
          <Row className="form-group">
            <Label htmlFor="name" md="2">Tên</Label>
            <Col md={10} >
              <Control model=".name"
                value={name}
                className="form-control"
                validators={{
                  required, maxLength: maxLength(30), minLength: minLength(3)
                }}
              />
              <Errors
                className='text-danger'
                model=".name"
                messages={{
                  required: "Yêu cầu nhập",
                  maxLength: "yêu cầu nhập tối đa 30 ký tự ",
                  minLength: "yêu cầu nhập tối thiểu 3 ký tự"
                }}
              />
            </Col>
          </Row>
          <Row>
            <Label htmlFor="dOB" md="2">Ngày sinh</Label>
            <Col md={10} >
              <Control type="date" model=".dOB" name="dOB"
                value={doB}
                className="form-control"
                validators={{
                  required
                }}
              />
              <Errors
                className="text-danger"
                model=".dOB"
                messages={{
                  required: "Yêu cầu nhập"
                }}
              />
            </Col>
          </Row>
          <Row>
            <Label htmlFor="startDate" md="2">Ngày vào công ty</Label>
            <Col md={10} >
              <Control type="date" model=".startDate" name="startDate"
                value={startDate}
                className="form-control"
                validators={{
                  required
                }}
              />
              <Errors
                className='text-danger'
                model=".startDate"
                messages={{
                  required: "Yêu cầu nhập"
                }}
              />
            </Col>
          </Row>
          <Row>
            <Label htmlFor="departments" md={2}>Phòng ban</Label>
            <Col md={10} >
              <Control.select model=".departments" name="department" className="form-control" value={depart}>
                <option value="Dept01">Sale</option>
                <option value="Dept02">HR</option>
                <option value="Dept03">Marketing</option>
                <option value="Dept04">IT</option>
                <option value="Dept05">Finance</option>
              </Control.select >
            </Col>
          </Row>
          <Row>
            <Label htmlFor="salaryScale" md="2">Hệ số lương</Label>
            <Col md={10} >
              <Control type="number" model=".salaryScale" name="salaryScale"
                className="form-control"
              />
            </Col>
          </Row>
          <Row>
            <Label htmlFor="annualLeave" md="2">Số ngày nghỉ </Label>
            <Col md={10} >
              <Control type="number" model=".annualLeave" name="annualLeave"
                value={annual}
                className="form-control"
              />
            </Col>
          </Row>
          <Row>
            <Label htmlFor="overTime" md="2">Số ngày làm thêm</Label>
            <Col md={10} >
              <Control type="number" model=".overTime" name="overTime"
                value={overTime}
                className="form-control"
              />
            </Col>
          </Row>
          <Button type="submit" onClick={() => { }} color="primary"> Thêm </Button>
        </LocalForm>
      </ModalBody>
    </Modal>
  )
}

const DetailStaff = (props) => {
  return (
    <div className="container">
      <div className="row">
        <Breadcrumb>
          <BreadcrumbItem> <Link to="/home">Nhân viên</Link> </BreadcrumbItem>
          <BreadcrumbItem active>{props.staff.name} </BreadcrumbItem>
        </Breadcrumb>
      </div>
      <div className="row">
        {/* component render thẻ staff */}
        <RenderStaffs
          staff={props.staff}
          departName={props.departName}
        />
      </div>
    </div>
  )
}

export default DetailStaff;
